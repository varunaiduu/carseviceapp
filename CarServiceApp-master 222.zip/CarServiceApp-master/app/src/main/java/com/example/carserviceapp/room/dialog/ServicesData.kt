package com.example.carserviceapp.room.dialog

data class ServicesData(
    val serviceName : String,
    val servicePrice : String
) {
}