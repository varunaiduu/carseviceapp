package com.example.carserviceapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class cs_car_reports : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cs_car_reports)
    }
}